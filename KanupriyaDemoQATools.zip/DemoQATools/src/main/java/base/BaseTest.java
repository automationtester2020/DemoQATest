package base;

import io.cucumber.java.Before;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pageObjects.*;

import java.io.FileInputStream;
import java.util.Properties;

public class BaseTest {

    public static WebDriver driver;
    public static Properties prop;

/*@Before
    public static void dataProp() {
        prop = new Properties();
        try {
            FileInputStream fs = new FileInputStream(".//src//main//java//config//data.properties");
            prop.load(fs);
        } catch (Exception e) {

            e.printStackTrace();

        }

    }*/
}