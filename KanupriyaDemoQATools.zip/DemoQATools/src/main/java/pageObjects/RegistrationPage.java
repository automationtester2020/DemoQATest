package pageObjects;

import base.BaseTest;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;

public class RegistrationPage extends BaseTest {

    WebDriver driver;
    @FindBy(id="firstName") public WebElement FirstName;
    @FindBy(id="lastName") public WebElement LastName;
    @FindBy(id="userEmail") public WebElement Email;
    @FindBy(css="label.custom-control-label") public WebElement Gender;
    @FindBy(id="userNumber") public WebElement MobileNo;
    @FindBy(id="dateOfBirthInput") public WebElement DateOfBirth;
    @FindBy(xpath="//label[text()='Reading']") public WebElement Hobbies;
    @FindBy(id="uploadPicture") public WebElement Picture;
    @FindBy(id="currentAddress") public WebElement AddressBox;
    @FindBy(css="#state .css-tlfecz-indicatorContainer") public WebElement StateField;
    @FindBy(xpath="//div[text()='Uttar Pradesh']") public WebElement StateName;
    @FindBy(css="#city [class='css-19bqh2r']") public WebElement CityField;
    @FindBy(xpath="//div[text()='Lucknow']") public WebElement CityName;
    @FindBy(id="submit") public WebElement SubmitBtn;
    @FindBy(css="div[class='modal-header']") public WebElement SubmitMessage;

    @FindBy(id = "timerAlertButton") public WebElement SecondAlertBtn;
    @FindBy(id="toolTipButton") public WebElement HoverBtn;
    @FindBy(id="toolTipTextField") public WebElement HoverTextField;

    @FindBy(id="draggable") public WebElement DraggableFrame;
    @FindBy(id="droppable") public WebElement DroppableFrame;

    @FindBy(id="showSmallModal") public WebElement SmallModalBtn;
    @FindBy(xpath="//div[text()='This is a small modal. It has very less content']") public WebElement ModalText;
    @FindBy(id="closeSmallModal") public WebElement CloseSmallModBtn;

    @FindBy(id="datePickerMonthYearInput") public WebElement DatePickerField;
    @FindBy(className = "react-datepicker__month-select") public WebElement MonthSelector;
    @FindBy(css="div[class='react-datepicker__day react-datepicker__day--020 react-datepicker__day--weekend']") public WebElement Date;


    public RegistrationPage(WebDriver driver)
    {
        this.driver=driver;
        PageFactory.initElements(driver,this);

    }

    public void firstName(String firstname)
    {
        FirstName.sendKeys(firstname);
    }

    public void lastName(String lastname)
    {
    LastName.sendKeys(lastname);
    }

    public void email(String email){
        Email.sendKeys(email);
    }

    public void maleRadioBtn(){
        Gender.click();
    }

    public void mobileNo(String Mobile){
        MobileNo.sendKeys(Mobile);
    }

    public void dateOfBirth(){
        DateOfBirth.click();
       Select s = new Select(driver.findElement(By.cssSelector("select.react-datepicker__month-select")));
       s.selectByValue("0");

       Select s1 = new Select(driver.findElement(By.cssSelector("select.react-datepicker__year-select")));
       s1.selectByValue("2000");

       driver.findElement(By.xpath("//div[text()='11']")).click();

    }

    public void hobbies(){
        Hobbies.click();
    }

    public void picture(){
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);",
                driver.findElement(By.id("uploadPicture")));
    Picture.sendKeys("K:\\KANU\\COURSES\\TESTING\\DemoQATools\\image.jpg");

    }

    public void address(String Address){
        AddressBox.sendKeys(Address);
    }

    public void state(){
    StateField.click();
    StateName.click();
    }

    public void city(){
        CityField.click();
        CityName.click();
    }

    public void submit() {
        SubmitBtn.click();

    }

    public void submitmessage() throws IOException {
    System.out.println(SubmitMessage.getText());
    TakesScreenshot ts = (TakesScreenshot)driver;
    File file = ts.getScreenshotAs(OutputType.FILE);
    FileUtils.copyFile(file, new File("./Screenshot/FormMessage1.jpg"));
    }


    public void secondAlertBtn() {
        SecondAlertBtn.click();
        WebDriverWait wait = new WebDriverWait(driver, 5);
        wait.until(ExpectedConditions.alertIsPresent());
        driver.switchTo().alert().accept();
    }


    public void hoverBtn(){
        Actions a = new Actions(driver);
        a.moveToElement(HoverBtn).perform();
        WebDriverWait wait = new WebDriverWait(driver, 3000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("toolTipTextField")));
    }

    public void hoverTextField(){
        Actions a1 = new Actions(driver);
        a1.moveToElement(HoverTextField).perform();
    }


    public void dragAndDrop(){
        WebDriverWait wait = new WebDriverWait(driver, 3000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("draggable")));
        Actions a2 = new Actions(driver);
        a2.dragAndDrop(DraggableFrame, DroppableFrame).perform();
    }


    public void smallModalBtn(){
        SmallModalBtn.click();
        WebDriverWait wait = new WebDriverWait(driver, 4);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()='Close']")));
    }

    public void modalText(){
        String smallmodaltext= ModalText.getText();
        System.out.println(smallmodaltext);
    }

    public void closeSmallModBtn(){
        CloseSmallModBtn.click();
    }

    public void datePickerField(){
        DatePickerField.click();
        Select m = new Select(MonthSelector);
        m.selectByValue("1");
        Date.click();
    }

}
