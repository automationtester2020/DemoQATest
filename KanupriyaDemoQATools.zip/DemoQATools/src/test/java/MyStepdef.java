import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pageObjects.RegistrationPage;

import java.io.IOException;

public class MyStepdef {
    RegistrationPage registrationPage;
    WebDriver driver;

    @Before
    public void startBrowser(){
        WebDriverManager.chromedriver().setup();
        driver=new ChromeDriver();
        System.out.println("Driver set up");
        driver.navigate().to(driver.getCurrentUrl());
        driver.manage().window().maximize();
        registrationPage = new RegistrationPage(driver);
    }

    @After
    public void stopBrowser(){
        driver.quit();
    }


    @Given("user is on {string}")
    public void userIsOn(String url) {
    driver.navigate().to(url);
    }

    @When("user enters {string}, {string}, {string}, Gender, {string}, DateOfBirth")
    public void userEntersGenderDateOfBirth(String FirstName, String LastName, String Email, String Mobile) {

        registrationPage.firstName(FirstName);
        registrationPage.lastName(LastName);
        registrationPage.email(Email);
        registrationPage.maleRadioBtn();
        registrationPage.mobileNo(Mobile);
        registrationPage.dateOfBirth();
    }

    @And("user enters Hobbies, Picture")
    public void userEntersHobbiesPicture() {

        registrationPage.hobbies();
        registrationPage.picture();
    }


    @And("user enters {string}, State, City")
    public void userEntersStateCity(String Address) {
        registrationPage.address(Address);
        registrationPage.state();
        registrationPage.city();
    }

    @When("clicks on Submit button")
    public void clicks_on_submit_button() {
        registrationPage.submit();
    }

    @Then("user should see the PopupMessage")
    public void userShouldSeeThePopupMessage() throws IOException {
        registrationPage.submitmessage();
    }


    @Then("user clicks on second alert button and accepts the alert")
    public void userClicksOnSecondAlertButtonAndAcceptsTheAlert() {
        registrationPage.secondAlertBtn();
    }


    @And("user hovers over HoverMeToSeeButton")
    public void userHoversOverHoverMeToSeeButton() {

       registrationPage.hoverBtn();
    }

    @Then("user also hovers over HoverMeToSeeField")
    public void userAlsoHoversOverHoverMeToSeeField() {
        registrationPage.hoverTextField();
    }


    @Then("user drags and drops the DragMe frame into DropHere frame")
    public void userDragsAndDropsTheDragMeFrameIntoDropHereFrame() {
        registrationPage.dragAndDrop();
    }


    @When("user selects small modal button")
    public void userSelectsSmallModalButton() {
         registrationPage.smallModalBtn();
    }

    @Then("user closes the modal")
    public void user_closes_the_modal() {
        registrationPage.modalText();
        registrationPage.closeSmallModBtn();
    }


    @Then("user selects a date one month from today's date in SelectDate field")
    public void userSelectsADateOneMonthFromTodaySDateInSelectDateField() {
        registrationPage.datePickerField();
    }


}